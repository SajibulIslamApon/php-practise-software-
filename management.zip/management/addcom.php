
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "employee";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


    $name=$_POST["comname"];
    $address=$_POST["comaddress"];
    $phone_Number=$_POST["comnumber"];
    


$sql = "INSERT INTO tbl_company (com_name,com_address,com_phone)
VALUES ('$name', '$address', '$phone_Number')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
  header("Location:addcompany.php");
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>


