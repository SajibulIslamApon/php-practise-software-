

<?php
include('header.php');
?>

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Companies</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>



        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Companies Table</h3>

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                    <div class="input-group-append">
                      <button type="submit" class="btn btn-default">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 300px;">
                <table class="table" id="myTable" action="Companies.php" method="post" >
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Company Name</th>
                      <th>Company Address</th>
                      <th>company Number</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>


                  <?php
                  $servername = "localhost";
                  $username = "root";
                  $password = "";
                  $dbname = "employee";

                  // Create connection
                  $conn = new mysqli($servername, $username, $password, $dbname);
                  // Check connection
                  if ($conn->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                  }

                  $sql = "SELECT* FROM tbl_company";
                  $result = $conn->query($sql);
                  

                  if ($result->num_rows > 0) {
                  // output data of each row
                  while($row = $result->fetch_assoc()) {
                      echo "<tr>
                              <td>".$row["com_id"]."</td>
                              <td>".$row["com_name"]."</td>
                              <td>".$row["com_address"]."</td>
                              <td>".$row["com_phone"]."</td>
                              <td><a href='deletecom.php?comid=$row[com_id]'>Delete</a></td>
                              <td><a href='updatecom.php?id=$row[com_id]'>Update</a></td>
                              
                            </tr>";
                            
                          
                  }
                  } else {
                  echo "0 results";
                  }
                  $conn->close();
                  ?>







                  </tbody>
                </table>
              </div>
             
              <!-- /.card-body -->
            </div >
            <!-- /.card -->
          </div>
        </div>
        <!-- /.row -->

<?php
include('footer.php');
?>

<script>

(document).ready( function () {
$('#myTable').DataTable();
} );
</script>
















