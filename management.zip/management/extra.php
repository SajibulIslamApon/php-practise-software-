
         <table id="table_id" >
           <thead>
                  <tr>
                    <th>Company Name</th>
                    <th>Employee Name</th>
                    <th>Location</th>
                    <th>Joining Date</th>
                  </tr>
            </thead>
            <tbody>
            <?php
    var_dump($_REQUEST);
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "employee";

                    $name=$_POST["CompanyName"];
                    $address=$_POST["Locationid"];
                    $join=$_POST["joiningdate"];
                   
                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);
                    // Check connection
                    if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                    }

                  //   $sql = "SELECT tbl_company.com_name,tbl_employee.tbl_location,tbl_employee.  
                  //   FROM tbl_employee
                  //    JOIN tbl_company ON tbl_employee.com_id  = tbl_company.com_id 
                  //  ";
                  //   $result = $conn->query($sql);


                    /*$sql = "SELECT tbl_company.com_name, tbl_employee.tbl_location, tbl_employee.tbl_joining_date
                    FROM tbl_company
                    JOIN tbl_employee ON tbl_company.com_id=tbl_employee.com_id
                    WHERE com_name='$name'";*/
                    $sql = "SELECT tbl_company.com_name, tbl_employee.emp_name, tbl_employee.tbl_location, tbl_employee.tbl_joining_date
                    FROM tbl_company
                    JOIN tbl_employee ON tbl_company.com_id=tbl_employee.com_id
                    where tbl_company.com_id='".$name."' AND tbl_employee.tbl_location like '".$address."' AND tbl_employee.tbl_joining_date = '".$join."' ";
                    //echo $sql;
                    //exit(1);
                    $result = $conn->query($sql);

                    // echo "<pre>";
                    // print_r($result);
                    // echo "</pre>";

                    // WHERE tbl_company.com_name=$comname
                    // WHERE tbl_employee.tbl_location=$location
                    // WHERE tbl_employee.tbl_joining_date=$joiningdate

                    if ($result->num_rows > 0) {
                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>".$row["com_name"]."</td>
                                <td>".$row["emp_name"]."</td>
                                <td>".$row["tbl_location"]."</td>
                                <td>".$row["tbl_joining_date"]."</td>
                            </tr>";
                 
                    }
                    } 
                    $conn->close();
                    ?>



            </tbody>
          </table>

      </div>
