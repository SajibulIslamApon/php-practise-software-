

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "employee";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$id=$_POST["emp_id"];
$name=$_POST["empname"];
$mail=$_POST["empmail"];
$phone_Number=$_POST["empnumber"];
$com_id=$_POST["companyid"];
    


$sql = "UPDATE tbl_employee SET emp_name='$name',emp_email='$mail',emp_phone='$$phone_Number',com_id='$com_id'WHERE emp_id='$id' ";

if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";
  header("Location:employees.php");
} else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();
?>



