<?php
include('header.php');
?>

<?php
if(isset($_FILES['exampleInputFile'])){

  echo "<pre>";
  print_r($_FILES);
  echo "</pre>";

  $_file_name=$_FILES['exampleInputFile']['name'];
  $_file_Size=$_FILES['exampleInputFile']['size'];
  $_file_tmp=$_FILES['exampleInputFile']['tmp_name'];
  $_file_type=$_FILES['exampleInputFile']['type'];

  move_uploaded_file($_file_tmp,"photos/".$_file_name);
}
?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add Employee</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-6">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Add Info</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="addemp.php" method="post" enctype="multipart/form-data">
                <div class="card-body">

                  <div class="form-group">
                    <label for="exampleInputName">Name</label>
                    <input type="text" class="form-control" id="empname" name="empname" placeholder="Enter Name">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputEmail">Email</label>
                    <input type="text" class="form-control" id="empmail" name="empmail" placeholder="Enter Email">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputNumber">Phone Number</label>
                    <input type="text" class="form-control" id="empnumber" name="empnumber" placeholder="Enter Number">
                  </div>





                  <div class="form-group">
                  <label>Company ID </label>
                  <select class="form-control" style="width: 100%;" id="companyid" name="companyid" >
                  <?php

                  $servername = "localhost";
                  $username = "root";
                  $password = "";
                  $dbname = "employee";

                                    // Create connection
                  $conn = new mysqli($servername, $username, $password, $dbname);
                                    // Check connection
                  if ($conn->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                  }


                  $sql = "SELECT * FROM tbl_company order by com_id desc";
                 // var_dump($sql);
                  $result = $conn->query($sql);
                  $result2 = mysqli_fetch_assoc($result);
                                    
                  while( $result2 = mysqli_fetch_assoc($result)) {
                      echo"<option value=".$result2["com_id"].">
                          ".$result2["com_name"]."   
                          </option>";
                                        
                  }
                                  
                  $conn->close();
                  ?>
                  </select>
                  </div>





                  <div class="form-group">
                    <label for="exampleInputName">Location<label>
                    <input type="text" class="form-control" id="location" name="location" placeholder="Enter Location">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputName">Joining Date<label>
                    <input type="date" class="form-control" id="joiningdate" name="joiningdate" placeholder="Enter Joinig date ">
                  </div>
                  
                 
                    
                    <input type="file" id="image" name="image" />
                    
                    
                 
                  
                  
                  
              
                <!-- /.card-body -->
               
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
            <!-- /.card -->


<?php
include('footer.php');
?>



