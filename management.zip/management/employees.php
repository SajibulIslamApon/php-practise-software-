<?php
include('header.php');
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Employees</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>



        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Employees Table</h3>

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                    <div class="input-group-append">
                      <button type="submit" class="btn btn-default">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 300px;">
                <table class="table table-head-fixed text-nowrap" action="employees.php" method="post" >
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Employee Name's</th>
                      <th>Employee Mail's</th>
                      <th>Employee Phone's</th>
                      <th>Company ID's</th>
                     
                    </tr>
                  </thead>
                  <tbody>
                    


                    
        
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "employee";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT* FROM tbl_employee";
        $result = $conn->query($sql);
        

        if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
          //echo "<tr><td>".$row["emp_id"]."</td><td>".$row["emp_name"]."<td> ".$row["emp_name"]."<td> ".$row["emp_phone"]."<td> ".$row["com_id"]."<td> ".'<button type="button" class="btn btn-block btn-info">Update</button>'."<td> ".'<button type="button" class="btn btn-block btn-danger">Delete</button>'."</td></tr>";
         
//          $image="photos\".$row["tbl_emp_image"]; 
          echo "<tr>
                  <td>".$row["emp_id"]."</td>
                  <td>".$row["emp_name"]."</td>
                  <td>".$row["emp_email"]."</td>
                  <td>".$row["emp_phone"]."</td>
                  <td>".$row["com_id"]."</td>
                  
                  <td><img src='photos/".$row['tbl_emp_image']."' width=auto height=50px/></td>
                  <td><a href='deleteemp.php?empid=$row[emp_id]'>Delete</a></td>
                  <td><a href='updateemp.php?id=$row[emp_id] '>Update</a></td>
                  
                </tr>";
           
        }
        } else {
        echo "0 results";
        }
        $conn->close();
        ?>

                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>
        <!-- /.row -->





        <?php
        include('footer.php');
        ?>
        
        