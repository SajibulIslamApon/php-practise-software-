
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "employee";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
    $id=$_POST["com_id"];
    $name=$_POST["comname"];
    $address=$_POST["comaddress"];
    $phone_Number=$_POST["comnumber"];
    

$sql = "UPDATE tbl_company SET com_name='$name',com_address='$address',com_phone='$phone_Number' WHERE com_id='$id'";

if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";
  header("Location:companies.php");
} else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();
?>



