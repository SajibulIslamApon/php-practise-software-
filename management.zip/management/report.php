<?php
include('header.php');
?>
           
           <form action="report.php" method="post">
                 <div class="content-wrapper">
    
                  <section class="content-header">

                  <div class="form-group">
                  <label>Company Name </label>
                  <select class="form-control" style="width: 20%;" id="CompanyName" name="CompanyName" >
                  
                  <?php

                  $servername = "localhost";
                  $username = "root";
                  $password = "";
                  $dbname = "employee";

                                    // Create connection
                  $conn = new mysqli($servername, $username, $password, $dbname);
                                    // Check connection
                  if ($conn->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                  }


                  $sql = "SELECT * FROM tbl_company order by com_id desc";
            
                  $result = $conn->query($sql);
                  $result2 = mysqli_fetch_assoc($result);

              
                                    
                  while( $result2 = mysqli_fetch_assoc($result)) {
                      echo"<option value= '".$result2["com_id"]."' >".$result2["com_name"]."</option>";
                                        
                  }
                                  
                  $conn->close();
                  ?>
                  </select>
                  </div>

                  <div class="form-group">
                  <label>Location </label>
                  <select class="form-control" style="width: 20%;" id="Locationid" name="Locationid" >
                  <?php

                  $servername = "localhost";
                  $username = "root";
                  $password = "";
                  $dbname = "employee";

                                    // Create connection
                  $conn = new mysqli($servername, $username, $password, $dbname);
                                    // Check connection
                  if ($conn->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                  }


                  $sql = "SELECT * FROM tbl_employee ";
                  $result = $conn->query($sql);
                  $result2 = mysqli_fetch_assoc($result);
                                    
                  while( $result2 = mysqli_fetch_assoc($result)) {
                      echo"<option value='".$result2["tbl_location"]."' >".$result2["tbl_location"]."</option>";
                                        
                  }
                                  
                  $conn->close();
                  ?>
                  </select>
                  </div>


                  <div class="form-group">
                  <label>Joining Date </label>
                  <input name='joiningdate' type='date'>
                  </div>

                         
         
           
              

                <button type="submit" class="btn btn-primary">Report</button>

                </form>
<br>

<br>
<br>
<br>

<!-- reporting strat -->
<?php 
if(isset($_POST)){
?>
       <table id="table_id" >
           <thead>
                  <tr>
                    <th>Company Name</th>
                    <th>Employee Name</th>
                    <th>Location</th>
                    <th>Joining Date</th>
                  </tr>
            </thead>
            <tbody>
            <?php
    //var_dump($_REQUEST);
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "employee";

                    $name=$_POST["CompanyName"];
                    $address=$_POST["Locationid"];
                    $join=$_POST["joiningdate"];
                   
                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);
                    // Check connection
                    if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                    }

                  //   $sql = "SELECT tbl_company.com_name,tbl_employee.tbl_location,tbl_employee.  
                  //   FROM tbl_employee
                  //    JOIN tbl_company ON tbl_employee.com_id  = tbl_company.com_id 
                  //  ";
                  //   $result = $conn->query($sql);


                    /*$sql = "SELECT tbl_company.com_name, tbl_employee.tbl_location, tbl_employee.tbl_joining_date
                    FROM tbl_company
                    JOIN tbl_employee ON tbl_company.com_id=tbl_employee.com_id
                    WHERE com_name='$name'";*/
                    $sql = "SELECT tbl_company.com_name, tbl_employee.emp_name, tbl_employee.tbl_location, tbl_employee.tbl_joining_date
                    FROM tbl_company
                    JOIN tbl_employee ON tbl_company.com_id=tbl_employee.com_id
                    where tbl_company.com_id='".$name."' AND tbl_employee.tbl_location like '".$address."' AND tbl_employee.tbl_joining_date = '".$join."' ";
                    //echo $sql;
                    //exit(1);
                    $result = $conn->query($sql);

                    // echo "<pre>";
                    // print_r($result);
                    // echo "</pre>";

                    // WHERE tbl_company.com_name=$comname
                    // WHERE tbl_employee.tbl_location=$location
                    // WHERE tbl_employee.tbl_joining_date=$joiningdate

                    if ($result->num_rows > 0) {
                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>".$row["com_name"]."</td>
                                <td>".$row["emp_name"]."</td>
                                <td>".$row["tbl_location"]."</td>
                                <td>".$row["tbl_joining_date"]."</td>
                            </tr>";
                 
                    }
                    } 
                    $conn->close();
                    ?>



            </tbody>
          </table>

      </div>
      <?php } ?>
<!-- Report ends -->



 
<?php
include('footer.php');
?>
<script>
$(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>
".$result2["com_id"]." >