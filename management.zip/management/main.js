$(document).ready(function() {
    $('#table_id').DataTable();
});