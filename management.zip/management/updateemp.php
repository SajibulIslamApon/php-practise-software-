<?php
                  $servername = "localhost";
                  $username = "root";
                  $password = "";
                  $dbname = "employee";

                  // Create connection
                  $conn = new mysqli($servername, $username, $password, $dbname);
                  // Check connection
                  if ($conn->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                  }
                  $id=$_GET['id'];

                  $sql = "SELECT* FROM tbl_employee WHERE emp_id=$id";
                  $result = $conn->query($sql);
                  $result2 = mysqli_fetch_assoc($result);
                  

                 
                  $conn->close();
                  ?>


<?php
include('header.php');
?>



  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Update Employee</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-6">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Add Info</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="updateempdatabase.php" method="post">
              <input type="hidden" name="emp_id" id="emp_id" value='<?php echo $result2['emp_id']?>'>
                <div class="card-body">

                  <div class="form-group">
                    <label for="exampleInputName">Name</label>
                    <input type="text" value='<?php echo $result2['emp_name']?>' class="form-control" id="empname" name="empname" placeholder="Enter Name">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputEmail">Email</label>
                    <input type="text" value='<?php echo $result2['emp_email']?>' class="form-control" id="empmail" name="empmail" placeholder="Enter Email">
                  </div>

                  
                  <div class="form-group">
                    <label for="exampleInputNumber">Phone Number</label>
                    <input type="text" value='<?php echo $result2['emp_phone']?>' class="form-control" id="empnumber" name="empnumber" placeholder="Enter Number">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputNumber">Company ID</label>
                    <input type="text" value='<?php echo $result2['com_id']?>'class="form-control" id="companyid" name="companyid" placeholder="Enter Company ID">
                  </div>
                  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" href='updateempdatabase.php?id=$row[emp_id]'  class="btn btn-primary">Update</button>
                </div>
              </form>
            </div>
            <!-- /.card -->


<?php
include('footer.php');
?>



