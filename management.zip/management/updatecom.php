
         <?php
                  $servername = "localhost";
                  $username = "root";
                  $password = "";
                  $dbname = "employee";

                  // Create connection
                  $conn = new mysqli($servername, $username, $password, $dbname);
                  // Check connection
                  if ($conn->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                  }
                  $id=$_GET['id'];

                  $sql = "SELECT* FROM tbl_company WHERE com_id=$id";
                  $result = $conn->query($sql);
                  $result2 = mysqli_fetch_assoc($result);
                  

                 
                  $conn->close();
                  ?>







<?php
include('header.php');
?>



  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Update Company</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-6">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Add Info</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="updatecomdatabase.php" method="post">
              <input type="hidden" name="com_id" id="com_id" value='<?php echo $result2['com_id']?>'>
                  
                <div class="card-body">

                  <div class="form-group">
                    <label for="exampleInputName"> Company Name</label>
                    <input type="text"  value='<?php echo $result2['com_name']?>' class="form-control" id="comname" name="comname" placeholder="Enter Name">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputEmail">Company Address</label>
                    <input type="text" value='<?php echo $result2['com_address']?>' class="form-control" id="comaddress" name="comaddress" placeholder="Enter Address">
                  </div>

                  
                  <div class="form-group">
                    <label for="exampleInputNumber">Phone Number</label>
                    <input type="text" value='<?php echo $result2['com_phone']?>'  class="form-control" id="comnumber" name="comnumber" placeholder="Enter Number">
                  </div>

                  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Update</button>
                </div>
              </form>
            </div>
            <!-- /.card -->


<?php
include('footer.php');
?>


